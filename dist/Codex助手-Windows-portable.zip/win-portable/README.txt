Codex助手 Windows Portable 版
================================

首次使用：
1. 双击 install_deps.bat 安装依赖（需要联网，约1分钟）
2. 双击 Codex助手.bat 启动应用

后续使用：
直接双击 Codex助手.bat 即可

注意：需要 Windows 10 或以上版本
