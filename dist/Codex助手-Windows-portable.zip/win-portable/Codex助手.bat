@echo off
chcp 65001 >nul 2>&1
title Codex助手

REM 检查是否已安装依赖
if not exist "%~dp0\python\Lib\site-packages\pywebview" (
    echo 首次运行，需要安装依赖...
    call "%~dp0\install_deps.bat"
)

REM 启动应用
cd /d "%~dp0"
"%~dp0\python\python.exe" "%~dp0\src\web_launcher.py"
if errorlevel 1 (
    echo.
    echo 应用启动失败，请确保已运行 install_deps.bat 安装依赖
    pause
)
